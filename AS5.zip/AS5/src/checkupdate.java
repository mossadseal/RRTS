
public class checkupdate {
	
	private Integer holdmanp=0;
	private Integer holdmacp=0;
	private Integer id=0;
	
	
	
	public Integer getholdmanp(){
		return holdmanp;
		
	}
	
	public void setholdmanp(Integer h){
		
		holdmanp=h;
	}

	public Integer getholdmacp(){
		return holdmacp;
		
	}
	
	public void setholdmacp(Integer h){
		
		holdmacp=h;
	}
	
	public Integer getid(){
		return id;
		
	}
	
	public void setid(Integer h){
		
		id=h;
	}
		
	
	

}
