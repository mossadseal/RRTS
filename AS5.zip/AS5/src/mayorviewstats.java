/*
import java.awt.Color;
import java.awt.EventQueue;
import java.sql.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class mayorviewstats extends JFrame {

	private static JTable table;
	private static JTextField textField;
	private static JTextField textId;
	private static JTextField textFname;
	private static JTextField textLname;
	private static JTextField textAge;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	

	
static Connection conn;
	public mayorviewstats() {
		 // create JFrame and JTable
       
        DefaultTableModel model = new DefaultTableModel();
        addWindowListener(new WindowAdapter() {
        	@Override
        	public void windowClosed(WindowEvent e) {
        	
     	try {
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        		
        	}
        	
        	Object[] row1=new Object[8];
        	@Override
        	public void windowOpened(WindowEvent e) {
        		
        		
        		PreparedStatement yt;
				try{
	
					try {
						Class.forName("org.sqlite.JDBC");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					try{
						
						conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\bharath\\Documents\\Databasesqlite\\AdminData.sqlite");
						JOptionPane.showMessageDialog(null, "SUCCESSFUL CONNECTION");
						
						
					}
					
					
					catch(Exception e3){
						
						JOptionPane.showMessageDialog(null, "NOT SUCCESSFUL CONNECTION");
						
					}
				
					yt = conn.prepareStatement("select * from ComplaintData");
					ResultSet rd=yt.executeQuery();
					
					 int i;
	                 int y=model.getRowCount();
	                 for(i=0;i<y;i++)
	                 model.removeRow(i);
	        		
					while(rd.next()){
						
	        		 row1[0] = rd.getString("AreaCode");
	                 row1[1] = rd.getString("ComplaintType");
	                 row1[2] = rd.getString("ComplaintDetails");
	                 row1[3] = rd.getString("ManPower");
	                 row1[4] = rd.getString("MachinePower");
	                 row1[5] = rd.getString("RawMaterials");
	                 row1[6] = rd.getString("ComplaintDate");
	                 row1[7] = rd.getString("IsScheduled");
	                 model.addRow(row1);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

                 // add row to the model
                 
        	}
        });
        JTable table = new JTable(); 
        // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Areacode","ComplaintType","ComplaintDetails","ManPower","MachinePower","RawMaterials","ComplaintDate","IsScheduled"};
        
        model.setColumnIdentifiers(columns);
       
         
        // set the model to the table
        table.setModel(model);
        
        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.black);
        Font font = new Font("",1,22);
        table.setFont(font);
        table.setRowHeight(30);
        
        // create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        table.setVisible(true);
        pane.setBounds(10, 11, 864, 786);
        
        getContentPane().setLayout(null);
       // pane.setSize(getWidth(), getHeight());
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
       getContentPane().add(pane);
        
        // create an array of objects to set the row data
        Object[] row = new Object[8];
        
       setSize(900,800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
        
    }
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mayorviewstats fr = new mayorviewstats();
					fr.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
      
}

*/


import java.awt.Color;
import java.awt.EventQueue;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JPanel;

public class mayorviewstats extends JFrame {

	private static JTable table;
	private static JTextField textField;
	private static JTextField textId;
	private static JTextField textFname;
	private static JTextField textLname;
	private static JTextField textAge;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	

	
static Connection conn;
	public mayorviewstats() {
		 // create JFrame and JTable
       
        DefaultTableModel model = new DefaultTableModel();
        addWindowListener(new WindowAdapter() {
        	@Override
        	public void windowClosed(WindowEvent e) {
        	
     	try {
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        		
        	}
        	
        	Object[] row1=new Object[8];
        	@Override
        	public void windowOpened(WindowEvent e) {
        		
        		
        		PreparedStatement yt;
				try{
	
					try {
						Class.forName("org.sqlite.JDBC");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					try{
						
						conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\bharath\\Documents\\Databasesqlite\\AdminData.sqlite");
						JOptionPane.showMessageDialog(null, "SUCCESSFUL CONNECTION");
						
						
					}
					
					
					catch(Exception e3){
						
						JOptionPane.showMessageDialog(null, "NOT SUCCESSFUL CONNECTION");
						
					}
				
					yt = conn.prepareStatement("select * from ComplaintData");
					ResultSet rd=yt.executeQuery();
					
					 int i;
	                 int y=model.getRowCount();
	                 for(i=0;i<y;i++)
	                 model.removeRow(i);
	        		
					while(rd.next()){
						
	        		 row1[0] = rd.getString("AreaCode");
	                 row1[1] = rd.getString("ComplaintType");
	                 row1[2] = rd.getString("ComplaintDetails");
	                 row1[3] = rd.getString("ManPower");
	                 row1[4] = rd.getString("MachinePower");
	                 row1[5] = rd.getString("RawMaterials");
	                 row1[6] = rd.getString("ComplaintDate");
	                 row1[7] = rd.getString("IsScheduled");
	                 model.addRow(row1);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

                 // add row to the model
                 
        	}
        });
        JTable table = new JTable(); 
        // create a table model and set a Column Identifiers to this model 
        Object[] columns = {"Areacode","ComplaintType","ComplaintDetails","ManPower","MachinePower","RawMaterials","ComplaintDate","IsScheduled"};
        
        model.setColumnIdentifiers(columns);
       
         
        // set the model to the table
        table.setModel(model);
        
        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.black);
        Font font = new Font("",1,22);
        table.setFont(font);
        table.setRowHeight(30);
        
        // create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        table.setVisible(true);
        pane.setBounds(10, 11, 864, 535);
        
        getContentPane().setLayout(null);
       // pane.setSize(getWidth(), getHeight());
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
       getContentPane().add(pane);
        
        // create an array of objects to set the row data
        Object[] row = new Object[8];
        
       setSize(895,632);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
        
    }
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mayorviewstats fr = new mayorviewstats();
					fr.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}

